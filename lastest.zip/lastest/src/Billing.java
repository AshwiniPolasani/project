import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Billing")
public class Billing extends HttpServlet
 {
PreparedStatement st=null;
Connection con=null;
public void init()
{
System.out.println("init");
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123456789");

}
catch(Exception ae)
{}
}

    public void doGet(HttpServletRequest request, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<h1><center>CUSTOMER BILLING REPORT </h1><hr>"); 



        out.println("<table border=2>");
        out.println("<tr>");
        out.print("<tr><th>Customer Name</th><th>Email</th><th>Phone</th><th>Total Amount</th></tr>");
        	 out.println("</tr>");
        try 
        {

        Statement st1=con.createStatement();
        	
        	ResultSet rs=st1.executeQuery("select * from customers");
        	HttpSession ses=request.getSession(false);//new session is created
        while(rs.next())
        {
        out.println("<tr><td>");
        out.println(rs.getString(1));
        out.println("<td>");
        out.println(rs.getString(2));
        out.println("<td>");
        out.println(rs.getString(4));
        out.println("<td>");
        String d=(String)ses.getAttribute("t");
int total=Integer.parseInt(d);
        out.println(total);
        out.println("<td>");
        }
        out.println("<h1>Order Placed Successfully and Will be deliverd in 3 days</h1>");
        }
        catch(Exception at)
        {at.printStackTrace();}
                 
           } }