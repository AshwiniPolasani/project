import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/cart")
public class cart extends HttpServlet
 {
PreparedStatement st=null;
Connection con=null;
public void init()
{
System.out.println("init");
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123456789");

}
catch(Exception ae)
{}
}

    public void doGet(HttpServletRequest request, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();


     HttpSession hs =   request.getSession();
    String lgname = (String) hs.getAttribute("lgname");
int total=0; 
String x1=request.getParameter("cb1");
 String x2=request.getParameter("cb2");
 String x3=request.getParameter("cb3");
 String x4=request.getParameter("cb4");
 String x5=request.getParameter("cb5");
 String x6=request.getParameter("cb6");
 String x7=request.getParameter("cb7");
 String x8=request.getParameter("cb8");
 String x9=request.getParameter("cb9");
 String x10=request.getParameter("cb10");
 String x11=request.getParameter("cb11");
 String x12=request.getParameter("cb12");
 String x13=request.getParameter("cb13");
 String x14=request.getParameter("cb14");
 String x15=request.getParameter("cb15");
 String x16=request.getParameter("cb16");
 String x17=request.getParameter("cb17");
 String x18=request.getParameter("cb18");
 String x19=request.getParameter("cb19");
 String x20=request.getParameter("cb20");
 String x21=request.getParameter("cb21");
 String x22=request.getParameter("cb22");
 String x23=request.getParameter("cb23");
 String x24=request.getParameter("cb24");
 String x25=request.getParameter("cb25");
 String x26=request.getParameter("cb26");
 String x27=request.getParameter("cb27");
 String x28=request.getParameter("cb28");
 String x29=request.getParameter("cb29");
 String x30=request.getParameter("cb30");
 String x31=request.getParameter("cb31");
 String x32=request.getParameter("cb32");
 String x33=request.getParameter("cb33");
 String x34=request.getParameter("cb34");
 String x35=request.getParameter("cb35");
 String x36=request.getParameter("cb36");
 String x37=request.getParameter("cb37");
 String x38=request.getParameter("cb38");
 String x39=request.getParameter("cb39");
 String x40=request.getParameter("cb40");
 String x41=request.getParameter("cb41");
 String x42=request.getParameter("cb42");
 String x43=request.getParameter("cb43");
 String x44=request.getParameter("cb44");
 String x45=request.getParameter("cb45");
 String x46=request.getParameter("cb46");
 String x47=request.getParameter("cb47");
 String x48=request.getParameter("cb48");
 String x49=request.getParameter("cb49");
 String x50=request.getParameter("cb50");
 String x51=request.getParameter("cb51");
 String x52=request.getParameter("cb52");
 String x53=request.getParameter("cb53");
 String x54=request.getParameter("cb54");
 String x55=request.getParameter("cb55");
 String x56=request.getParameter("cb56");
 String x57=request.getParameter("cb57");
 String x58=request.getParameter("cb58");
 String x59=request.getParameter("cb59");
 String x60=request.getParameter("cb60");
 String x61=request.getParameter("cb61");
 String x62=request.getParameter("cb62");
 String x63=request.getParameter("cb63");
 String x64=request.getParameter("cb64");
 String x65=request.getParameter("cb65");
 String x66=request.getParameter("cb66");
 String x67=request.getParameter("cb67");
 String x68=request.getParameter("cb68");
 String x69=request.getParameter("cb69");
 String x70=request.getParameter("cb70");
 String x71=request.getParameter("cb71");
 String x72=request.getParameter("cb72");
if(x1!=null)
{
	int a1=Integer.parseInt(x1);
	total=total+a1;
}
if(x2!=null)
{
	int a2=Integer.parseInt(x2);
	total=total+a2;
}
if(x3!=null)
{
	int a3=Integer.parseInt(x3);
	total=total+a3;
}
if(x4!=null)
{
	int a4=Integer.parseInt(x4);
	total=total+a4;
}
if(x5!=null)
{
	int a5=Integer.parseInt(x5);
	total=total+a5;
}
if(x6!=null)
{
	int a6=Integer.parseInt(x6);
	total=total+a6;
}
if(x7!=null)
{
	int a7=Integer.parseInt(x7);
	total=total+a7;
}
if(x8!=null)
{
	int a8=Integer.parseInt(x8);
	total=total+a8;
} 

if(x9!=null)
{
	int a9=Integer.parseInt(x9);
	total=total+a9;
}
if(x10!=null)
{
	int a10=Integer.parseInt(x10);
	total=total+a10;
}
if(x11!=null)
{
	int a11=Integer.parseInt(x11);
	total=total+a11;
}
if(x12!=null)
{
	int a12=Integer.parseInt(x12);
	total=total+a12;
}
if(x13!=null)
{
	int a13=Integer.parseInt(x13);
	total=total+a13;
}
if(x14!=null)
{
	int a14=Integer.parseInt(x14);
	total=total+a14;
}
if(x15!=null)
{
	int a15=Integer.parseInt(x15);
	total=total+a15;
}
if(x16!=null)
{
	int a16=Integer.parseInt(x16);
	total=total+a16;
} 
 
if(x17!=null)
{
	int a17=Integer.parseInt(x17);
	total=total+a17;
}
if(x18!=null)
{
	int a18=Integer.parseInt(x18);
	total=total+a18;
}
if(x19!=null)
{
	int a19=Integer.parseInt(x19);
	total=total+a19;
}
if(x20!=null)
{
	int a20=Integer.parseInt(x20);
	total=total+a20;
}
if(x21!=null)
{
	int a21=Integer.parseInt(x21);
	total=total+a21;
}
if(x22!=null)
{
	int a22=Integer.parseInt(x22);
	total=total+a22;
}
if(x23!=null)
{
	int a23=Integer.parseInt(x23);
	total=total+a23;
}
if(x24!=null)
{
	int a24=Integer.parseInt(x24);
	total=total+a24;
} 

if(x25!=null)
{
	int a25=Integer.parseInt(x25);
	total=total+a25;
}
if(x26!=null)
{
	int a26=Integer.parseInt(x26);
	total=total+a26;
}
if(x27!=null)
{
	int a27=Integer.parseInt(x27);
	total=total+a27;
}
if(x28!=null)
{
	int a28=Integer.parseInt(x28);
	total=total+a28;
}
if(x29!=null)
{
	int a29=Integer.parseInt(x29);
	total=total+a29;
}
if(x30!=null)
{
	int a30=Integer.parseInt(x30);
	total=total+a30;
}
if(x31!=null)
{
	int a31=Integer.parseInt(x31);
	total=total+a31;
}
if(x32!=null)
{
	int a32=Integer.parseInt(x32);
	total=total+a32;
} 
if(x33!=null)
{
	int a33=Integer.parseInt(x33);
	total=total+a33;
}
if(x34!=null)
{
	int a34=Integer.parseInt(x34);
	total=total+a34;
}
if(x35!=null)
{
	int a35=Integer.parseInt(x35);
	total=total+a35;
}
if(x36!=null)
{
	int a36=Integer.parseInt(x36);
	total=total+a36;
}
if(x37!=null)
{
	int a37=Integer.parseInt(x37);
	total=total+a37;
}
if(x38!=null)
{
	int a38=Integer.parseInt(x38);
	total=total+a38;
}
if(x39!=null)
{
	int a39=Integer.parseInt(x39);
	total=total+a39;
}
if(x40!=null)
{
	int a40=Integer.parseInt(x40);
	total=total+a40;
} 
if(x41!=null)
{
	int a41=Integer.parseInt(x41);
	total=total+a41;
}
if(x42!=null)
{
	int a42=Integer.parseInt(x42);
	total=total+a42;
}
if(x43!=null)
{
	int a43=Integer.parseInt(x43);
	total=total+a43;
}
if(x44!=null)
{
	int a44=Integer.parseInt(x44);
	total=total+a44;
}
if(x45!=null)
{
	int a45=Integer.parseInt(x45);
	total=total+a45;
}
if(x46!=null)
{
	int a46=Integer.parseInt(x46);
	total=total+a46;
}
if(x47!=null)
{
	int a47=Integer.parseInt(x47);
	total=total+a47;
}
if(x48!=null)
{
	int a48=Integer.parseInt(x48);
	total=total+a48;
} 
if(x49!=null)
{
	int a49=Integer.parseInt(x49);
	total=total+a49;
}
if(x50!=null)
{
	int a50=Integer.parseInt(x50);
	total=total+a50;
}
if(x51!=null)
{
	int a51=Integer.parseInt(x51);
	total=total+a51;
}
if(x52!=null)
{
	int a52=Integer.parseInt(x52);
	total=total+a52;
}
if(x53!=null)
{
	int a53=Integer.parseInt(x53);
	total=total+a53;
}
if(x54!=null)
{
	int a54=Integer.parseInt(x54);
	total=total+a54;
}
if(x55!=null)
{
	int a55=Integer.parseInt(x55);
	total=total+a55;
}
if(x56!=null)
{
	int a56=Integer.parseInt(x56);
	total=total+a56;
}
if(x57!=null)
{
	int a57=Integer.parseInt(x57);
	total=total+a57;
} 
if(x58!=null)
{
	int a58=Integer.parseInt(x58);
	total=total+a58;
}
if(x59!=null)
{
	int a59=Integer.parseInt(x59);
	total=total+a59;
}
if(x60!=null)
{
	int a60=Integer.parseInt(x60);
	total=total+a60;
}
if(x61!=null)
{
	int a61=Integer.parseInt(x61);
	total=total+a61;
}
if(x62!=null)
{
	int a62=Integer.parseInt(x62);
	total=total+a62;
}
if(x63!=null)
{
	int a63=Integer.parseInt(x63);
	total=total+a63;
}
if(x64!=null)
{
	int a64=Integer.parseInt(x64);
	total=total+a64;
} 
if(x65!=null)
{
	int a65=Integer.parseInt(x65);
	total=total+a65;
}
if(x66!=null)
{
	int a66=Integer.parseInt(x66);
	total=total+a66;
}
if(x67!=null)
{
	int a67=Integer.parseInt(x67);
	total=total+a67;
}
if(x68!=null)
{
	int a68=Integer.parseInt(x68);
	total=total+a68;
}
if(x69!=null)
{
	int a69=Integer.parseInt(x69);
	total=total+a69;
}
if(x70!=null)
{
	int a70=Integer.parseInt(x70);
	total=total+a70;
}
if(x71!=null)
{
	int a71=Integer.parseInt(x71);
	total=total+a71;
}
if(x72!=null)
{
	int a72=Integer.parseInt(x72);
	total=total+a72;
}
try 
{

	PreparedStatement st=con.prepareStatement("insert into rate values(?)");
	st.setInt(1,total);
	
	st.execute();
}
catch(Exception at)
{} 
out.println("<h1>");


out.println("<h1><center>CUSTOMER BILLING REPORT </h1><hr>"); 



out.println("<table border=2>");
out.println("<tr>");
out.print("<tr><th>Customer Name</th><th>Email</th><th>Phone</th><th>Total Amount</th></tr>");
	 out.println("</tr>");
try 
{
Statement st=con.createStatement();
st.execute("truncate table customers");

Statement st2=con.createStatement();
st2.execute("truncate table rate");


Statement st1=con.createStatement();
	
	ResultSet rs=st1.executeQuery("select * from customers");

	HttpSession ses=request.getSession(true);//new session is created
	
	while(rs.next())
{

String a=rs.getString(1);
ses.setAttribute("x",a);
String b=rs.getString(2);
ses.setAttribute("y",b);
String c=rs.getString(4);
ses.setAttribute("z",c);
int tot=total;
ses.setAttribute("t",tot);

}
}
catch(Exception at)
{at.printStackTrace();}
         
   } 



 }
 

