import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Forgotpassword")

public class Forgotpassword extends HttpServlet {
	PreparedStatement st = null;
	Connection con = null;
	ResultSet rs = null;
	public void init() {
		System.out.println("init");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "123456789");

		} catch (Exception ae) {
			System.out.println("Sorry! Database is not connected");
		}
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();

		String a = req.getParameter("t1");
		String b = req.getParameter("t2");
	
		HttpSession ses = req.getSession(true);// New Session is created
		ses.setAttribute("x", a);
		ses.setAttribute("y", b);
	
		try {

			st = con.prepareStatement("select * from Customers where email=? and phone_no=?");
			st.setString(1, a);
			st.setString(2, b);
		
			rs = st.executeQuery();
			while (rs.next())
			{
				res.sendRedirect("forgotpassword2.html");	
			}
				res.sendRedirect("forgot1.html");

		} catch (Exception at) {
			out.println("Sorry! unable to retrieve record");

		}
		

		out.println("</body>");
		out.println("</html>");
	}

}